document.addEventListener("DOMContentLoaded", function () {
    const timerElement = document.getElementById("timer");
    const quizForm = document.getElementById("quizForm");

    if (timerElement && quizForm) {
        let timeLeft = parseInt(timerElement.dataset.duration);

        function updateTimer() {
            let minutes = Math.floor(timeLeft / 60);
            let seconds = timeLeft % 60;

            timerElement.textContent =
                `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                alert("Time is up! Quiz will be submitted automatically.");
                quizForm.submit();
            }

            timeLeft--;
        }

        updateTimer();
        const timerInterval = setInterval(updateTimer, 1000);
    }
});