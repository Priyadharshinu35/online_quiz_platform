from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.user_login, name='login'),
    path('register/', views.user_register, name='register'),
    path('logout/', views.user_logout, name='logout'),
    path('history/', views.user_history, name='user_history'),
    path('profile/', views.user_profile, name='user_profile'),
    path('admin-panel/', views.admin_panel, name='admin_panel'),
    path('delete-user/<int:user_id>/', views.delete_user, name='delete_user'),
    path('delete-inactive-users/', views.delete_inactive_users, name='delete_inactive_users'),
]