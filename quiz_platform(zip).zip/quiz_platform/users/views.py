from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.contrib.auth.models import User
from django.db.models import Avg
from .forms import RegisterForm, LoginForm
from quiz_app.models import QuizAttempt


def user_register(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful.')
            return redirect('home')
    else:
        form = RegisterForm()

    return render(request, 'users/register.html', {'form': form})


def user_login(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, 'Login successful.')
            return redirect('home')
    else:
        form = LoginForm()

    return render(request, 'users/login.html', {'form': form})


def user_logout(request):
    logout(request)
    messages.success(request, 'Logout successful.')
    return redirect('login')


@login_required
def user_history(request):
    attempts = QuizAttempt.objects.filter(user=request.user).select_related('quiz').order_by('-completed_at')
    return render(request, 'users/history.html', {'attempts': attempts})


@login_required
def user_profile(request):
    attempts = QuizAttempt.objects.filter(user=request.user).select_related('quiz').order_by('-completed_at')

    total_attempts = attempts.count()
    best_attempt = attempts.order_by('-score', '-percentage').first()
    best_score = best_attempt.score if best_attempt else 0

    avg_percentage = attempts.aggregate(avg=Avg('percentage'))['avg']
    average_percentage = round(avg_percentage, 2) if avg_percentage else 0

    recent_attempts = attempts[:5]

    context = {
        'total_attempts': total_attempts,
        'best_score': best_score,
        'average_percentage': average_percentage,
        'recent_attempts': recent_attempts,
    }
    return render(request, 'users/profile.html', context)


def is_admin_user(user):
    return user.is_staff or user.is_superuser


@login_required
@user_passes_test(is_admin_user)
def admin_panel(request):
    all_users = User.objects.all().order_by('-date_joined')
    users_data = []

    for user in all_users:
        attempts = QuizAttempt.objects.filter(user=user)
        best_attempt = attempts.order_by('-score', '-percentage').first()
        avg_percentage = attempts.aggregate(avg=Avg('percentage'))['avg']

        users_data.append({
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'is_active': user.is_active,
            'is_staff': user.is_staff,
            'is_superuser': user.is_superuser,
            'attempts_count': attempts.count(),
            'best_score': best_attempt.score if best_attempt else 0,
            'avg_percentage': round(avg_percentage, 2) if avg_percentage else 0,
            'date_joined': user.date_joined,
        })

    context = {
        'users_data': users_data,
        'total_users': User.objects.count(),
        'active_users': User.objects.filter(is_active=True).count(),
        'inactive_users': User.objects.filter(is_active=False).count(),
        'total_attempts': QuizAttempt.objects.count(),
    }

    return render(request, 'users/admin_panel.html', context)


@login_required
@user_passes_test(is_admin_user)
def delete_user(request, user_id):
    user_to_delete = get_object_or_404(User, id=user_id)

    if user_to_delete == request.user:
        messages.error(request, 'You cannot delete your own account.')
        return redirect('admin_panel')

    if user_to_delete.is_staff or user_to_delete.is_superuser:
        messages.error(request, 'Admin users cannot be deleted from this panel.')
        return redirect('admin_panel')

    user_to_delete.delete()
    messages.success(request, 'User deleted successfully.')
    return redirect('admin_panel')


@login_required
@user_passes_test(is_admin_user)
def delete_inactive_users(request):
    inactive_users = User.objects.filter(is_active=False, is_staff=False, is_superuser=False)
    count = inactive_users.count()
    inactive_users.delete()
    messages.success(request, f'{count} inactive user(s) deleted successfully.')
    return redirect('admin_panel')