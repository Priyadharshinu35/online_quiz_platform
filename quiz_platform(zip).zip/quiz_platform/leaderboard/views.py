from django.shortcuts import render
from quiz_app.models import QuizAttempt, Quiz


def leaderboard_view(request):
    quiz_id = request.GET.get('quiz')
    quizzes = Quiz.objects.filter(is_published=True)

    attempts = QuizAttempt.objects.select_related('user', 'quiz').all()

    if quiz_id:
        attempts = attempts.filter(quiz_id=quiz_id)

    attempts = attempts.order_by('user_id', 'quiz_id', '-score', '-percentage', '-completed_at')

    best_attempts = []
    seen = set()

    for attempt in attempts:
        key = (attempt.user_id, attempt.quiz_id)
        if key not in seen:
            seen.add(key)
            best_attempts.append(attempt)

    best_attempts = sorted(
        best_attempts,
        key=lambda x: (-x.score, -x.percentage, -(x.completed_at.timestamp() if x.completed_at else 0))
    )

    leaderboard_data = []
    rank = 1

    for attempt in best_attempts:
        leaderboard_data.append({
            'rank': rank,
            'username': attempt.user.username,
            'quiz_title': attempt.quiz.title,
            'score': attempt.score,
            'percentage': attempt.percentage,
            'correct_answers': attempt.correct_answers,
            'wrong_answers': attempt.wrong_answers,
            'completed_at': attempt.completed_at,
        })
        rank += 1

    selected_quiz_id = int(quiz_id) if quiz_id and quiz_id.isdigit() else None

    return render(request, 'leaderboard/leaderboard.html', {
        'leaderboard_data': leaderboard_data,
        'quizzes': quizzes,
        'selected_quiz_id': selected_quiz_id,
    })