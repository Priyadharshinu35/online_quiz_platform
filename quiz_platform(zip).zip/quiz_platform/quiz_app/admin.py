from django.contrib import admin
from .models import Category, Quiz, Question, Option, QuizAttempt, UserAnswer


class OptionInline(admin.TabularInline):
    model = Option
    extra = 4


class QuestionAdmin(admin.ModelAdmin):
    list_display = ['question_text', 'quiz', 'marks']
    inlines = [OptionInline]


class QuizAdmin(admin.ModelAdmin):
    list_display = ['title', 'category', 'difficulty_level', 'duration', 'total_marks', 'is_published']
    list_filter = ['category', 'difficulty_level', 'is_published']
    search_fields = ['title']


admin.site.register(Category)
admin.site.register(Quiz, QuizAdmin)
admin.site.register(Question, QuestionAdmin)
admin.site.register(QuizAttempt)
admin.site.register(UserAnswer)
