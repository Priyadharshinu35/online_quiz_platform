from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone

from .models import Quiz, QuizAttempt, UserAnswer, Category


def quiz_list(request):
    quizzes = Quiz.objects.filter(is_published=True).select_related('category')
    categories = Category.objects.all()

    search_query = request.GET.get('search', '')
    category_id = request.GET.get('category', '')

    if search_query:
        quizzes = quizzes.filter(title__icontains=search_query)

    if category_id:
        quizzes = quizzes.filter(category_id=category_id)

    return render(request, 'quiz_app/quiz_list.html', {
        'quizzes': quizzes,
        'categories': categories,
        'search_query': search_query,
        'selected_category': category_id,
    })


def quiz_detail(request, quiz_id):
    quiz = get_object_or_404(Quiz, id=quiz_id, is_published=True)
    questions_count = quiz.questions.count()

    already_attempted = False
    if request.user.is_authenticated:
        already_attempted = QuizAttempt.objects.filter(user=request.user, quiz=quiz).exists()

    return render(request, 'quiz_app/quiz_detail.html', {
        'quiz': quiz,
        'questions_count': questions_count,
        'already_attempted': already_attempted
    })


@login_required
def start_quiz(request, quiz_id):
    quiz = get_object_or_404(Quiz, id=quiz_id, is_published=True)

    # restrict multiple attempts
    existing_attempt = QuizAttempt.objects.filter(user=request.user, quiz=quiz).first()
    if existing_attempt:
        messages.warning(request, 'You have already attempted this quiz.')
        return redirect('quiz_result', attempt_id=existing_attempt.id)

    questions = quiz.questions.prefetch_related('options').all()

    if request.method == 'POST':
        total_questions = questions.count()
        correct_answers = 0
        wrong_answers = 0
        total_score = 0

        attempt = QuizAttempt.objects.create(
            user=request.user,
            quiz=quiz,
            total_questions=total_questions
        )

        for question in questions:
            selected_option_id = request.POST.get(f'question_{question.id}')
            selected_option = None
            is_correct = False

            if selected_option_id:
                selected_option = question.options.filter(id=selected_option_id).first()

                if selected_option and selected_option.is_correct:
                    is_correct = True
                    correct_answers += 1
                    total_score += question.marks
                else:
                    wrong_answers += 1
                    total_score -= quiz.negative_mark
            else:
                wrong_answers += 1

            UserAnswer.objects.create(
                attempt=attempt,
                question=question,
                selected_option=selected_option,
                is_correct=is_correct
            )

        percentage = 0
        if quiz.total_marks > 0:
            percentage = (total_score / quiz.total_marks) * 100

        attempt.score = total_score
        attempt.correct_answers = correct_answers
        attempt.wrong_answers = wrong_answers
        attempt.percentage = percentage
        attempt.completed_at = timezone.now()
        attempt.save()

        return redirect('quiz_result', attempt_id=attempt.id)

    return render(request, 'quiz_app/start_quiz.html', {
        'quiz': quiz,
        'questions': questions,
        'duration_seconds': quiz.duration * 60
    })


@login_required
def quiz_result(request, attempt_id):
    attempt = get_object_or_404(
        QuizAttempt.objects.select_related('quiz', 'user'),
        id=attempt_id,
        user=request.user
    )

    user_answers = attempt.user_answers.select_related('question', 'selected_option')
    return render(request, 'quiz_app/result.html', {
        'attempt': attempt,
        'user_answers': user_answers
    })