from django.shortcuts import render
from quiz_app.models import Quiz, QuizAttempt, Category


def home(request):
    total_quizzes = Quiz.objects.filter(is_published=True).count()
    total_categories = Category.objects.count()

    user_attempts = 0
    user_best_score = None

    if request.user.is_authenticated:
        user_attempts = QuizAttempt.objects.filter(user=request.user).count()
        best_attempt = QuizAttempt.objects.filter(user=request.user).order_by('-score', '-percentage').first()
        if best_attempt:
            user_best_score = best_attempt.score

    context = {
        'total_quizzes': total_quizzes,
        'total_categories': total_categories,
        'user_attempts': user_attempts,
        'user_best_score': user_best_score,
    }

    return render(request, 'dashboard/home.html', context)